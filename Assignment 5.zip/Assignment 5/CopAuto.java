import java.awt.Graphics;
import java.util.Random;
public class CopAuto  extends Auto {
	private static int xRatio, yRatio;

	public CopAuto()
	{
		super("LAPD", 30, new Engine("v300", 30, 5000), "cop-auto.jpg");	
		Random randX = new Random ();
		xRatio = randX.nextInt((5+5)-5);
		Random randY = new Random();
		yRatio = randY.nextInt((5+1)-5);
		super.fillUp();
		
	}	

	public void updateImage(Graphics g) {
	        super.updateImage(g);
	       drive( 20, (double)xRatio, (double)yRatio);
	 }
	public void updateState(int dx, int dy) {
		if (getX() < dx)
		{	
			// chnage  direction
			xRatio = - xRatio;
			yRatio = - yRatio;
			super.drive(2, xRatio, yRatio);
			
		}
		else if (getX() < 0) {
			// change direction
			xRatio = - xRatio;
			yRatio = - yRatio;
			super.drive(2, xRatio, yRatio);
			
		}
		else if (getY()  < dy) {
			// change direction
			xRatio = - xRatio;
			yRatio = - yRatio;
			super.drive(2, xRatio, yRatio);
			
		}
			else if (getY()< 0 ) {
				
				xRatio = - xRatio;
				yRatio = - yRatio;
				
				super.drive(2, xRatio, yRatio);
				
			}
			
	    }
	

}

